﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBuild
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBuild))
        Me.EmpressTheme1 = New builder.EmpressTheme()
        Me.btnMin = New builder.EmpressButton()
        Me.btnMax = New builder.EmpressButton()
        Me.btnClose = New builder.EmpressButton()
        Me.lnkClick = New System.Windows.Forms.LinkLabel()
        Me.btnBuild = New builder.EmpressButton()
        Me.txtSecondary = New builder.EmpressTextBox()
        Me.btnS = New builder.EmpressButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPrimary = New builder.EmpressTextBox()
        Me.btnP = New builder.EmpressButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EmpressTheme1.SuspendLayout()
        Me.SuspendLayout()
        '
        'EmpressTheme1
        '
        Me.EmpressTheme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.EmpressTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.EmpressTheme1.Controls.Add(Me.btnMin)
        Me.EmpressTheme1.Controls.Add(Me.btnMax)
        Me.EmpressTheme1.Controls.Add(Me.btnClose)
        Me.EmpressTheme1.Controls.Add(Me.lnkClick)
        Me.EmpressTheme1.Controls.Add(Me.btnBuild)
        Me.EmpressTheme1.Controls.Add(Me.txtSecondary)
        Me.EmpressTheme1.Controls.Add(Me.btnS)
        Me.EmpressTheme1.Controls.Add(Me.Label2)
        Me.EmpressTheme1.Controls.Add(Me.txtPrimary)
        Me.EmpressTheme1.Controls.Add(Me.btnP)
        Me.EmpressTheme1.Controls.Add(Me.Label1)
        Me.EmpressTheme1.Customization = "NS+h//////8="
        Me.EmpressTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EmpressTheme1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.EmpressTheme1.Image = Nothing
        Me.EmpressTheme1.Location = New System.Drawing.Point(0, 0)
        Me.EmpressTheme1.Movable = True
        Me.EmpressTheme1.Name = "EmpressTheme1"
        Me.EmpressTheme1.NoRounding = False
        Me.EmpressTheme1.Sizable = False
        Me.EmpressTheme1.Size = New System.Drawing.Size(598, 264)
        Me.EmpressTheme1.SmartBounds = True
        Me.EmpressTheme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.EmpressTheme1.TabIndex = 0
        Me.EmpressTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.EmpressTheme1.Transparent = False
        '
        'btnMin
        '
        Me.btnMin.Customization = "NS+h/wAAAP////83"
        Me.btnMin.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnMin.Image = Nothing
        Me.btnMin.Location = New System.Drawing.Point(514, 7)
        Me.btnMin.Name = "btnMin"
        Me.btnMin.NoRounding = False
        Me.btnMin.Size = New System.Drawing.Size(12, 12)
        Me.btnMin.TabIndex = 11
        Me.btnMin.Transparent = False
        '
        'btnMax
        '
        Me.btnMax.Customization = "NS+h/wAAAP////83"
        Me.btnMax.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnMax.Image = Nothing
        Me.btnMax.Location = New System.Drawing.Point(532, 7)
        Me.btnMax.Name = "btnMax"
        Me.btnMax.NoRounding = False
        Me.btnMax.Size = New System.Drawing.Size(12, 12)
        Me.btnMax.TabIndex = 10
        Me.btnMax.Transparent = False
        '
        'btnClose
        '
        Me.btnClose.Customization = "NS+h/wAAAP////83"
        Me.btnClose.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnClose.Image = Nothing
        Me.btnClose.Location = New System.Drawing.Point(550, 7)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NoRounding = False
        Me.btnClose.Size = New System.Drawing.Size(40, 12)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Transparent = False
        '
        'lnkClick
        '
        Me.lnkClick.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.lnkClick.BackColor = System.Drawing.Color.Transparent
        Me.lnkClick.DisabledLinkColor = System.Drawing.Color.LightGray
        Me.lnkClick.Font = New System.Drawing.Font("Segoe UI", 14.25!)
        Me.lnkClick.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.lnkClick.LinkColor = System.Drawing.Color.LightGray
        Me.lnkClick.Location = New System.Drawing.Point(187, 194)
        Me.lnkClick.Name = "lnkClick"
        Me.lnkClick.Size = New System.Drawing.Size(377, 42)
        Me.lnkClick.TabIndex = 8
        Me.lnkClick.TabStop = True
        Me.lnkClick.Text = "https://github.com/waived"
        Me.lnkClick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lnkClick.VisitedLinkColor = System.Drawing.Color.LightGray
        '
        'btnBuild
        '
        Me.btnBuild.Customization = "NS+h/wAAAP////83"
        Me.btnBuild.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnBuild.Image = Nothing
        Me.btnBuild.Location = New System.Drawing.Point(30, 194)
        Me.btnBuild.Name = "btnBuild"
        Me.btnBuild.NoRounding = False
        Me.btnBuild.Size = New System.Drawing.Size(151, 42)
        Me.btnBuild.TabIndex = 6
        Me.btnBuild.Text = "ꟷ> BIND <ꟷ"
        Me.btnBuild.Transparent = False
        '
        'txtSecondary
        '
        Me.txtSecondary.BackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.txtSecondary.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.txtSecondary.Location = New System.Drawing.Point(30, 149)
        Me.txtSecondary.Name = "txtSecondary"
        Me.txtSecondary.ReadOnly = True
        Me.txtSecondary.Size = New System.Drawing.Size(474, 23)
        Me.txtSecondary.TabIndex = 5
        '
        'btnS
        '
        Me.btnS.Customization = "NS+h/wAAAP////83"
        Me.btnS.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnS.Image = Nothing
        Me.btnS.Location = New System.Drawing.Point(510, 149)
        Me.btnS.Name = "btnS"
        Me.btnS.NoRounding = False
        Me.btnS.Size = New System.Drawing.Size(54, 23)
        Me.btnS.TabIndex = 4
        Me.btnS.Text = "...."
        Me.btnS.Transparent = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 14.25!)
        Me.Label2.ForeColor = System.Drawing.Color.LightGray
        Me.Label2.Location = New System.Drawing.Point(25, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Secondary"
        '
        'txtPrimary
        '
        Me.txtPrimary.BackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.txtPrimary.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.txtPrimary.Location = New System.Drawing.Point(30, 80)
        Me.txtPrimary.Name = "txtPrimary"
        Me.txtPrimary.ReadOnly = True
        Me.txtPrimary.Size = New System.Drawing.Size(474, 23)
        Me.txtPrimary.TabIndex = 2
        '
        'btnP
        '
        Me.btnP.Customization = "NS+h/wAAAP////83"
        Me.btnP.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnP.Image = Nothing
        Me.btnP.Location = New System.Drawing.Point(510, 80)
        Me.btnP.Name = "btnP"
        Me.btnP.NoRounding = False
        Me.btnP.Size = New System.Drawing.Size(54, 23)
        Me.btnP.TabIndex = 1
        Me.btnP.Text = "...."
        Me.btnP.Transparent = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 14.25!)
        Me.Label1.ForeColor = System.Drawing.Color.LightGray
        Me.Label1.Location = New System.Drawing.Point(25, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Primary"
        '
        'frmBuild
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(598, 264)
        Me.Controls.Add(Me.EmpressTheme1)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBuild"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vortex 1.1  ꟷ  File Binder/Joiner"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.EmpressTheme1.ResumeLayout(False)
        Me.EmpressTheme1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents EmpressTheme1 As EmpressTheme
    Friend WithEvents txtPrimary As EmpressTextBox
    Friend WithEvents btnP As EmpressButton
    Friend WithEvents Label1 As Label
    Friend WithEvents btnBuild As EmpressButton
    Friend WithEvents txtSecondary As EmpressTextBox
    Friend WithEvents btnS As EmpressButton
    Friend WithEvents Label2 As Label
    Friend WithEvents lnkClick As LinkLabel
    Friend WithEvents btnMin As EmpressButton
    Friend WithEvents btnMax As EmpressButton
    Friend WithEvents btnClose As EmpressButton
End Class
